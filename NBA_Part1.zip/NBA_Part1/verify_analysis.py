from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy import stats
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
P=Path(__file__).resolve().parent
raw=pd.read_csv(P/'data/nba_final.csv')
num=['Age','MP','PTS','AST','TRB','STL','BLK','TOV']
cols=['Salary','G','Pos1','Player_ID']+num
valid=raw[cols].notna().all(axis=1)&(raw.G>0)&(raw.Salary>0)
d=raw.loc[valid].copy()
rows=[]
for pid,g in d.groupby('Player_ID',sort=True):
    role=(g.groupby('Pos1').G.sum().rename('games').reset_index().sort_values(['games','Pos1'],ascending=[False,True]).iloc[0].Pos1)
    row={'Player_ID':pid,'Player':g['Player.x'].iloc[0],'Pos1':role,'n_seasons':g.Season.nunique(),'seasons':';'.join(sorted(g.Season)), 'total_games':int(g.G.sum()),'Salary_avg_million':g.Salary.mean()/1e6,'Age_avg':g.Age.mean()}
    for v in num[1:]:row[v+'_avg']=np.average(g[v],weights=g.G)
    rows.append(row)
a=pd.DataFrame(rows);a.to_csv(P/'data/nba_player_cleaned.csv',index=False)
levels=['C','PF','PG','SF','SG'];a.Pos1=pd.Categorical(a.Pos1,categories=levels)
xs=['PTS_avg','Age_avg','MP_avg','AST_avg','TRB_avg','STL_avg','BLK_avg','TOV_avg']
D=np.column_stack([(a.Pos1==v).astype(float) for v in levels[1:]])
base=np.column_stack([np.ones(len(a)),a[xs].values,D]);X=np.column_stack([base,D*a.PTS_avg.to_numpy()[:,None]])
names=['Intercept']+xs+['Pos1'+v for v in levels[1:]]+['PTS_avg:Pos1'+v for v in levels[1:]]
y=a.Salary_avg_million.to_numpy(); n,p=X.shape;df=n-p
b=np.linalg.lstsq(X,y,rcond=None)[0];e=y-X@b;rss=e@e;s2=rss/df
inv=np.linalg.inv(X.T@X);se=np.sqrt(np.diag(inv)*s2);crit=stats.t.ppf(.975,df)
coef=pd.DataFrame({'term':names,'estimate':b,'SE':se,'CI_low':b-crit*se,'CI_high':b+crit*se,'t':b/se,'p_value':2*stats.t.sf(abs(b/se),df)})
coef.to_csv(P/'results/coefficients.csv',index=False)
er=y-base@np.linalg.lstsq(base,y,rcond=None)[0];rr=er@er
F=((rr-rss)/4)/s2;pv=stats.f.sf(F,4,df);sst=((y-y.mean())**2).sum();r2=1-rss/sst
h=np.sum((X@inv)*X,axis=1);r=e/np.sqrt(s2*(1-h));cook=r*r*h/(p*(1-h))
audit=a[['Player_ID','Player','Pos1']].copy();audit['fitted']=X@b;audit['residual']=e;audit['standardized_residual']=r;audit['leverage']=h;audit['cooks_distance']=cook;audit.to_csv(P/'results/residuals.csv',index=False)
summary=[]
for v in ['Salary_avg_million']+xs:
 s=a[v];summary.append({'variable':v,'n':s.count(),'missing':s.isna().sum(),'mean':s.mean(),'SD':s.std(),'min':s.min(),'Q1':s.quantile(.25),'median':s.median(),'Q3':s.quantile(.75),'max':s.max(),'skew':s.skew()})
pd.DataFrame(summary).to_csv(P/'results/numeric_summary.csv',index=False)
a.Pos1.value_counts(sort=False).rename_axis('Pos1').reset_index(name='n').to_csv(P/'results/position_summary.csv',index=False)
metrics={'raw_rows':len(raw),'raw_columns':len(raw.columns),'raw_players':raw.Player_ID.nunique(),'retained_season_rows':len(d),'excluded_season_rows':len(raw)-len(d),'players':n,'excluded_players':raw.Player_ID.nunique()-n,'parameters':p,'rank':int(np.linalg.matrix_rank(X)),'df_residual':df,'R_squared':r2,'adjusted_R_squared':1-(1-r2)*(n-1)/df,'residual_SD_million':float(np.sqrt(s2)),'interaction_F':float(F),'interaction_p':float(pv),'interaction_df':[4,df],'overall_F':float(((sst-rss)/(p-1))/s2),'negative_fitted':int((X@b<0).sum()),'max_cooks_distance':float(cook.max()),'n_seasons_distribution':{str(k):int(v) for k,v in a.n_seasons.value_counts().sort_index().items()},'position_counts':{k:int((a.Pos1==k).sum()) for k in levels}}
(P/'results/metrics.json').write_text(json.dumps(metrics,indent=2))
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
fig,ax=plt.subplots(2,3,figsize=(14,8),layout='constrained')
ax[0,0].scatter(X@b,r,s=12,alpha=.45);ax[0,0].axhline(0,color='black',lw=1);ax[0,0].set(xlabel='Fitted salary (million USD)',ylabel='Standardized residual',title='Residuals vs fitted')
stats.probplot(r,dist='norm',plot=ax[0,1]);ax[0,1].set_title('Normal Q-Q')
ax[0,2].scatter(X@b,np.sqrt(abs(r)),s=12,alpha=.45);ax[0,2].set(xlabel='Fitted salary (million USD)',ylabel='sqrt(abs(standardized residual))',title='Scale-location')
ax[1,0].scatter(a.PTS_avg,r,s=12,alpha=.45);ax[1,0].axhline(0,color='black',lw=1);ax[1,0].set(xlabel='Weighted points per game',ylabel='Standardized residual',title='Residuals vs PTS')
ax[1,1].scatter(X@b,y,s=12,alpha=.45);lim=[min((X@b).min(),y.min()),max((X@b).max(),y.max())];ax[1,1].plot(lim,lim,color='black',lw=1);ax[1,1].set(xlabel='Fitted salary (million USD)',ylabel='Observed salary (million USD)',title='Observed vs fitted')
ax[1,2].scatter(h,r,s=12,alpha=.45);ax[1,2].axhline(0,color='black',lw=1);ax[1,2].set(xlabel='Leverage',ylabel='Standardized residual',title='Residuals vs leverage')
fig.savefig(P/'results/diagnostics.png',dpi=160);plt.close(fig)
fig,axes=plt.subplots(2,4,figsize=(14,6),layout='constrained')
for ax,v in zip(axes.flat,xs):ax.scatter(a[v],r,s=9,alpha=.4);ax.axhline(0,color='black',lw=.7);ax.set(xlabel=v,ylabel='Standardized residual')
fig.savefig(P/'results/residuals_all_predictors.png',dpi=150);plt.close(fig)
assert n==a.Player_ID.nunique() and np.linalg.matrix_rank(X)==p
assert abs(e.sum())<1e-7 and np.max(abs(X.T@e))<1e-6
print(json.dumps(metrics,indent=2));print(coef.to_string(index=False))
