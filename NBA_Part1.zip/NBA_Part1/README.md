# STA302 NBA preliminary analysis

Unzip the entire folder. In RStudio open NBA_Part1_Analysis.Rmd and Knit to HTML.
Install rmarkdown and knitr if needed: install.packages(c('rmarkdown','knitr')).
The Rmd uses base R for models and plotting. Paths are relative to the Rmd folder.
Do not submit this ZIP as the proposal: the required proposal is a separate PDF.

Included: original CSV, player-level cleaned CSV, Rmd, independent Python
verification script, numerical results and diagnostic PNGs, and Chinese audit notes.

Execution status: Python OLS and cleaning were executed and algebraic checks passed.
R is unavailable in the execution environment: the Rmd has NOT been executed or knitted.
It contains an assertion to compare R coefficients with the independently computed
Python coefficients after matching term names. Run it in RStudio before submission.
Python dependencies: numpy, pandas, scipy, matplotlib. No Python model outputs need
be pasted into the proposal; the Rmd is the intended course implementation.

Data downloaded from https://www.kaggle.com/datasets/davra98/nba-players-20162019
on 2026-10-27. nba_final.csv is unchanged. Upstream provenance and salary conventions
still need checking before making substantive economic claims.
